const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');

const app = express();
const port = 3000;

// 添加这行代码
app.use(express.static('public'));

// 在其他中间件前调用这行代码
app.use(express.json());
app.use(bodyParser.json());



app.post('/run-sql', (req, res) => {
  const { bID } = req.body;

  try {
    // 读取 SQL 文件内容
    const sqlQuery = fs.readFileSync('C:\\Users\\王硕\\Desktop\\DataBase\\Database.sql', 'utf-8');

    // 将输入的 bID 放到 SQL 查询中的 A 处
    const formattedQuery = sqlQuery.replace(/A/g, `'${bID}'`);

    // 在实际应用中，你应该使用适当的查询方式，这里简单返回一个示例结果
    const result = [
      { year: 2022, month: 'July', salesCount: 5 },
    ];

    res.json(result);
  } catch (error) {
    // 处理错误
    res.status(500).json({ error: error.message });
  }
});

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
